<?php

namespace app\models;

use yii\base\Model;

class State extends Model
  {
    function getstate() {
       return array(array('s'=>'Selangor', 'ibn'=>'Shah Alam', 'kod'=>'SGR'),
              array('s'=>'Johor', 'ibn'=>'Johor Bahru', 'kod'=>'JHR'),
              array('s'=>'Kelantan', 'ibn'=>'Kota Bharu', 'kod'=>'KEL'),
              array('s'=>'kedah', 'ibn'=>'Alor Setar', 'kod'=>'KDH'),
              array('s'=>'Melaka', 'ibn'=>'Bandar Melaka', 'kod'=>'MEL'),
              array('s'=>'Negeri sembilan', 'ibn'=>'Seremban', 'kod'=>'NSN'),
              array('s'=>'Pahang', 'ibn'=>'Kuantan', 'kod'=>'PHG'),
              array('s'=>'Perak', 'ibn'=>'Ipoh', 'kod'=>'PRK'),
              array('s'=>'Perlis', 'ibn'=>'Kangar', 'kod'=>'PLS'),
              array('s'=>'Pulau Pinang', 'ibn'=>'Georgetown', 'kod'=>'PNG'),
              array('s'=>'Sabah', 'ibn'=>'kota Kinabalu', 'kod'=>'SBH'),
              array('s'=>'Sarawak', 'ibn'=>'Kuching', 'kod'=>'KCG'),
              array('s'=>'Terengganu', 'ibn'=>'Kuala Terengganu', 'kod'=>'TRG')
              );      
    }

	public function rules()
	{
	   return [
	   		[['s', 'ibn', 'kod'], 'required']
	   ];
	}
}
?>