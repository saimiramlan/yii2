<?php

namespace app\models;
use Yii;
use yii\base\Model;
use yii\db\Query;
use yii\db\ActiveRecord;

class Book extends ActiveRecord{
/*public $bookname;
public $publisher;
public $edition;
public $author;
public $price;
public $isbn;*/

   function attributeLabels()
   {
       return ["bookname" => "Nama buku", //Assign Attribute
       "publisher" => "Penerbit", //Assign Attribute
       "edition" => "Edisi", //Assign Attribute
       "author" => "Nama Pengarang", //Assign Attribute
       "price" => "Harga",
       "isbn" => "ISBN"]; //Assign Attribute
   }

   public static function book()
   {
      return "books";
   }


  public function rules()
  {
     return [
        [['bookname', 'publisher', 'author', 'price'], 'required']
     ];
  }

  public function getListUseCommand()
  {
    // return a set of rows. each row is an associative array of column names and values.
    // an empty array is returned if the query returned no results
    $bookAll = Yii::$app->db->createCommand('SELECT * FROM book')
    ->queryAll();

    return $bookAll;
  }

  public function getTableList()
  {
    $book = (new Query())->select('*')->from('book')->where('id=1')->all();
    return $book;
  }

  public function storeTable($bookArray)
  {
    $book = new Book();
    $book->bookname = $bookArray['bookname'];
    $book->publisher = $bookArray['publisher'];
    $book->edition = $bookArray['edition'];
    $book->author = $bookArray['author'];
    $book->price = $bookArray['price'];
    $book->isbn = $bookArray['isbn'];
    $book->save();
  }

  public function updateTable($id, $bookArray)
  {
    $book = Book::findOne($id);
    $book->bookname = $bookArray['Book']['bookname'];
    $book->publisher = $bookArray['Book']['publisher'];
    $book->edition = $bookArray['Book']['edition'];
    $book->author = $bookArray['Book']['author'];
    $book->price = $bookArray['Book']['price'];
    $book->isbn = $bookArray['Book']['isbn'];
    $book->save();
  }

  public function deleteTable($id)
  {
    $book = Book::findOne($id);
    $book->delete();
  }
}
?>