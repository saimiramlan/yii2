<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=127.0.0.1;dbname=myfirstyii2',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
