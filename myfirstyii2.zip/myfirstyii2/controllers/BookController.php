<?php

namespace app\controllers;

use yii;
use yii\web\Controller;
use app\models\Book;

class BookController extends Controller
{
	/*public function actionList()
	{
		return $this->render('list');
	}*/

	public function actionList()
	{
		$bookModel = new Book();
		return $this->render('list', ['bookModel' => $bookModel,]);
	}
	public function actionAdd()
	{
		$bookModel = new Book();
		$bookname = '';
		if ($bookModel->load(Yii::$app->request->post())) 
		{
			$bookModel->storeTable(Yii::$app->request->post()['Book']);
			return $this->render('list', ['bookModel' => $bookModel]);
		}else
		{
			return $this->render('add', 
				['bookModel' => $bookModel,
				 'bookname' => $bookname]);
		}
	}

	public function actionEdit()
	{
		$bookModel = Book::findOne(Yii::$app->request->get('id'));
		$bookname = '';
		if ($bookModel->load(Yii::$app->request->post())) 
		{
			$bookModel->updateTable(Yii::$app->request->get('id'), Yii::$app->request->post());
			return $this->render('list', ['bookModel' => $bookModel]);
		}else
		{
			return $this->render('edit', 
				['bookModel' => $bookModel,
				 'bookname' => $bookname]);
		}

	}

	public function actionDelete()
	{
		$bookModel = new Book();
		$bookname = '';
		if (Yii::$app->request->get()) 
		{
			$bookModel->deleteTable(Yii::$app->request->get('id'));
			return $this->redirect('/book/list');
		}else
		{
			return $this->render('list', 
				['bookModel' => $bookModel,
				 'bookname' => $bookname]);
		}
	}
}

?>
