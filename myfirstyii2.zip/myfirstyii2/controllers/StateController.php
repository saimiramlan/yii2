<?php

namespace app\controllers;

use yii;
use yii\web\Controller;
use app\models\State;

class StateController extends Controller
{
	public function actionList()
	{
		return $this->render('statetable');
	}
}

?>