<style type="text/css">
.bold {font-weight: bold;}
td{ text-align: center; }
td.fh{text-align: left;}
</style>

<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\models\State;

$this->title = 'State';
$this->params['breadcrumbs'][] = $this->title;;
$stateModel = new State;

echo "<table width=400px cellspacing='0' cellpadding='0' table align='center'><tr><td class=fh>Malaysia States</td></tr></table><br>";
	echo "<table border='1' width=400px cellspacing='0' cellpadding='0' table align='center'>";
	 foreach ($stateModel->getstate() as $states) {
       if ($states['kod']=='JHR'){
       echo "<tr><td class='bold'>". $states['s']. "</b></td><td class='bold'>". $states['ibn']. "</td><td class='bold'>". $states['kod']. "</td></tr>";
       }
       else
       { echo "<tr><td width=100px>". $states['s']. "</td><td width=100px>". $states['ibn']. "</td><td width=100px>". $states['kod']. "</td></tr>";}
   }
   echo "</table><hr/>";
   echo "<table width=400px cellspacing='0' cellpadding='0' table align='center'><tr><td class=fh><b>*Bold</b> state is the state you're living in.</td></tr></table>";
?>