<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
$this->title = 'Book';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="book-delete">
	<h1><?= Html::encode($this->title) ?></h1>
	<p>Sila isikan ruangan kosong di bawah:</p>
	<?php $form = ActiveForm::begin([ 'options' => ['class' => 'form-horizontal'],
	'fieldConfig' => [
	'template' => "{label}\n<div class=\"col-lg-3\">{input}{error}</div>",
	'labelOptions' => ['class' => 'col-lg-4 control-label'],
	]]); ?>
	<?= $form->field($bookModel, 'bookname') ?>
	<?= $form->field($bookModel, 'publisher') ?>
	<?= $form->field($bookModel, 'edition') ?>
	<?= $form->field($bookModel, 'author') ?>
	<?= $form->field($bookModel, 'price') ?>
	<?= $form->field($bookModel, 'isbn') ?>
	<?= Html::submitButton('Submit') ?>
	<?php ActiveForm::end(); ?>
</div>