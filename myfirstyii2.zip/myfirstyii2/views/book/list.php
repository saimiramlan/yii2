<style type="text/css">
.bold {font-weight: bold; background-color: green;}
table td{
	text-align: center;
	padding: 5px 11px;
}
hr{border-top: 1px solid;}
</style>

<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\models\Book;

$this->title = 'Book';
$this->params['breadcrumbs'][] = $this->title;
$bookModel = new Book;

$books = $bookModel->attributeLabels();
?>
<div class="site-list">
   <ul>
       <li><?php echo $books['bookname']; ?></li>
       <li><?php echo $books['publisher']; ?></li>
       <li><?php echo $books['edition']; ?></li>
       <li><?php echo $books['author']; ?></li>
       <li><?php echo $books['price']; ?></li>
   </ul>
</div>

<?php 
echo '<tr><td><a class="btn btn-xs btn-info" href="'.URL::to(['book/add']).'"">Add</a></td></tr>';
	echo "<table width=400px cellspacing='0' cellpadding='0' table align='center'><tr><td class=fh>Senarai Buku</td></tr></table><hr/>";
	echo "<table class='table table-striped .table-bordered' >";
		echo '<tr class=bold><td>' . "Nama buku" . '</td><td>' . "Penerbit" . '</td><td>' .
		"Edisi" . '</td><td>' . "Pengarang" . '</td><td>' . "Harga" . '</td><td>' . "ISBN" . '</td><td></td><td></td></tr>';
	foreach ($bookModel->getListUseCommand() as $book) 
	{
		echo '<tr><td>' . 
		$book['bookname'] . '</td><td>' . 
		$book['publisher'] . '</td><td>' .
		$book['edition'] . '</td><td>' . 
		$book['author'] . '</td><td>RM ' . 
		$book['price'] . '</td><td>' . 
		$book['isbn'] . '</td>
		<td><a class="btn btn-xs btn-success" href="'.URL::to(['book/edit', 'id'=>$book['id']]).'"">Edit</a></td>
		<td><a class="btn btn-xs btn-danger" href="'.URL::to(['book/delete', 'id'=>$book['id']]).'"">Delete</a></td>
		</tr>';
	} 
   echo "</table>";

 /*echo "<hr />";

   echo "<table width=400px cellspacing='0' cellpadding='0' table align='center'><tr><td class=fh>Buku istimewa</td></tr></table>";
	echo "<table class='table table-striped .table-bordered' >";
	echo '<tr class=bold><td>' . "Nama buku" . '</td><td>' . "Penerbit" . '</td><td>' .
		"Edisi" . '</td><td>' . "Pengarang" . '</td><td>' . "Harga" . '</td><td>' . "ISBN" . '</td></tr>';
	
	foreach ($bookModel->getTableList() as $book1) 
	{
		echo '<tr><td>' . $book1['bookname'] . '</td><td>' . $book1['publisher'] . '</td><td>' .
		$book1['edition'] . '</td><td>' . $book1['author'] . '</td><td>RM ' . $book1['price'] . '</td><td>' . $book1['isbn'] . '</td></tr>';
	}
   echo "</table>";*/

?>