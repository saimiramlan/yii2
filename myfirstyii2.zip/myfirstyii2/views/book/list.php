<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\models\Book;

$this->title = 'Book';
$this->params['breadcrumbs'][] = $this->title;;
$bookModel = new Book;

$books = $bookModel->attributeLabels();
?>
<div class="site-list">
   <ul>
       <li><?php echo $books['bookname']; ?></li>
       <li><?php echo $books['publisher']; ?></li>
       <li><?php echo $books['edition']; ?></li>
       <li><?php echo $books['author']; ?></li>
       <li><?php echo $books['price']; ?></li>
   </ul>
</div>